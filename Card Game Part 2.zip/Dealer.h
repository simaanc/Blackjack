//
// Created by Chris Simaan on 5/15/22.
//

#ifndef BLACKJACK_DEALER_H
#define BLACKJACK_DEALER_H


class Dealer {

};


#endif //BLACKJACK_DEALER_H
